package tn.esprit.rh.achat;

public class test {

}
